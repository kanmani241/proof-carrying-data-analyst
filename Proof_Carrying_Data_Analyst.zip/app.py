
import streamlit as st
import pandas as pd
import io
import contextlib
import os

# --------------------------------------------------
# PAGE SETTINGS
# --------------------------------------------------

st.set_page_config(
    page_title="Proof-Carrying Data Analyst",
    page_icon="📊",
    layout="wide"
)

st.title("📊 Proof-Carrying Data Analyst")
st.subheader("🤖 Agentic GenAI")

st.write(
    "Ask questions about messy real-world data. "
    "The agent checks the data, generates executable "
    "proof code, runs the proof and verifies the answer."
)

# --------------------------------------------------
# CREATE DATA
# --------------------------------------------------

os.makedirs("data", exist_ok=True)

customers = pd.DataFrame({
    "customer_id": [1, 2, 3, 4, 5],
    "name": ["Ravi", "Priya", "Arun", "Meena", "John"],
    "city": [
        "Chennai",
        "Chennai",
        "Bangalore",
        "Coimbatore",
        "Chennai"
    ]
})

orders = pd.DataFrame({
    "order_id": [101, 102, 103, 104, 105, 105, 106],
    "customer_id": [1, 2, 3, 4, 5, 5, 1],
    "amount": [5000, 3000, 7000, 4500, 2000, 2000, 100],
    "currency": [
        "INR",
        "INR",
        "INR",
        "INR",
        "INR",
        "INR",
        "USD"
    ],
    "date": [
        "2025-01-10",
        "2025-02-01",
        "2025-02-10",
        "2025-03-05",
        "2025-03-20",
        "2025-03-20",
        "2025-04-01"
    ]
})

products = pd.DataFrame({
    "product_id": [1, 2, 3],
    "product": [
        "Laptop",
        "Phone",
        "Headphones"
    ],
    "price": [
        50000,
        25000,
        3000
    ]
})

customers.to_csv(
    "data/customers.csv",
    index=False
)

orders.to_csv(
    "data/orders.csv",
    index=False
)

products.to_csv(
    "data/products.csv",
    index=False
)

# --------------------------------------------------
# DATA QUALITY
# --------------------------------------------------

duplicate_count = orders.duplicated(
    subset=["order_id"]
).sum()

currencies = orders["currency"].unique().tolist()

missing_values = (
    customers.isnull().sum().sum()
    + orders.isnull().sum().sum()
    + products.isnull().sum().sum()
)

# --------------------------------------------------
# SIDEBAR
# --------------------------------------------------

st.sidebar.title("📋 Project Information")

st.sidebar.write(
    "**HNX26PSI08**"
)

st.sidebar.write(
    "Proof-Carrying Data Analyst"
)

st.sidebar.write(
    "Agentic GenAI"
)

st.sidebar.divider()

st.sidebar.write("### Safety Checks")

if duplicate_count > 0:
    st.sidebar.warning(
        f"Duplicate IDs: {duplicate_count}"
    )
else:
    st.sidebar.success(
        "No duplicates"
    )

if len(currencies) > 1:
    st.sidebar.warning(
        "Multiple currencies detected"
    )
else:
    st.sidebar.success(
        "Single currency"
    )

st.sidebar.write(
    f"Missing values: {missing_values}"
)

# --------------------------------------------------
# DATA VIEW
# --------------------------------------------------

with st.expander("📁 View Available Data"):

    st.write("### Customers")

    st.dataframe(
        customers,
        use_container_width=True
    )

    st.write("### Orders")

    st.dataframe(
        orders,
        use_container_width=True
    )

    st.write("### Products")

    st.dataframe(
        products,
        use_container_width=True
    )

# --------------------------------------------------
# DATA QUALITY REPORT
# --------------------------------------------------

with st.expander("🔍 Data Quality Report"):

    col1, col2, col3 = st.columns(3)

    col1.metric(
        "Customers",
        len(customers)
    )

    col2.metric(
        "Orders",
        orders["order_id"].nunique()
    )

    col3.metric(
        "Products",
        len(products)
    )

    st.write(
        "Currencies:",
        ", ".join(currencies)
    )

    if duplicate_count > 0:
        st.warning(
            f"⚠️ Duplicate order IDs found: "
            f"{duplicate_count}"
        )

    if len(currencies) > 1:
        st.warning(
            "⚠️ INR and USD cannot be directly added."
        )

# --------------------------------------------------
# REFUSAL FUNCTION
# --------------------------------------------------

def refused(reason, checks):

    checks.append(
        "❌ " + reason
    )

    return {
        "status": "REFUSED",
        "answer": None,
        "code": "",
        "checks": checks,
        "reason": reason
    }

# --------------------------------------------------
# ANALYZE QUESTION
# --------------------------------------------------

def analyze_question(question):

    q = question.lower().strip()

    checks = []

    checks.append(
        "✓ customers.csv loaded"
    )

    checks.append(
        "✓ orders.csv loaded"
    )

    checks.append(
        "✓ products.csv loaded"
    )

    if not q:

        return refused(
            "No question was entered.",
            checks
        )

    # ----------------------------------------------
    # UNSUPPORTED QUESTIONS
    # ----------------------------------------------

    external_words = [
        "weather",
        "temperature",
        "prime minister",
        "president",
        "stock price",
        "movie",
        "cricket",
        "football",
        "news",
        "population",
        "salary",
        "age",
        "height",
        "religion",
        "college ranking"
    ]

    for word in external_words:

        if word in q:

            return refused(
                "This information is not available "
                "in the supplied data.",
                checks
            )

    # ----------------------------------------------
    # CUSTOMER COUNT
    # ----------------------------------------------

    if (
        "how many customers" in q
        or "number of customers" in q
        or "customer count" in q
    ):

        code = """
import pandas as pd

customers = pd.read_csv(
    "data/customers.csv"
)

answer = customers["customer_id"].nunique()

print(answer)
"""

        answer = customers[
            "customer_id"
        ].nunique()

        checks.append(
            "✓ customer_id column found"
        )

        checks.append(
            "✓ Unique customers calculated"
        )

        return {
            "status": "ANSWER",
            "answer": str(answer),
            "code": code,
            "checks": checks,
            "reason": "Customer count"
        }

    # ----------------------------------------------
    # ORDER COUNT
    # ----------------------------------------------

    if (
        "how many orders" in q
        or "number of orders" in q
        or "order count" in q
    ):

        code = """
import pandas as pd

orders = pd.read_csv(
    "data/orders.csv"
)

orders = orders.drop_duplicates(
    subset=["order_id"]
)

answer = orders["order_id"].nunique()

print(answer)
"""

        clean_orders = orders.drop_duplicates(
            subset=["order_id"]
        )

        answer = clean_orders[
            "order_id"
        ].nunique()

        checks.append(
            "✓ Duplicate orders removed"
        )

        checks.append(
            "✓ Unique orders counted"
        )

        return {
            "status": "ANSWER",
            "answer": str(answer),
            "code": code,
            "checks": checks,
            "reason": "Order count"
        }

    # ----------------------------------------------
    # PRODUCT COUNT
    # ----------------------------------------------

    if (
        "how many products" in q
        or "number of products" in q
        or "product count" in q
    ):

        code = """
import pandas as pd

products = pd.read_csv(
    "data/products.csv"
)

answer = products["product_id"].nunique()

print(answer)
"""

        answer = products[
            "product_id"
        ].nunique()

        checks.append(
            "✓ product_id column found"
        )

        checks.append(
            "✓ Products counted"
        )

        return {
            "status": "ANSWER",
            "answer": str(answer),
            "code": code,
            "checks": checks,
            "reason": "Product count"
        }

    # ----------------------------------------------
    # CITIES
    # ----------------------------------------------

    if (
        "which cities" in q
        or "what cities" in q
        or "list cities" in q
    ):

        city_list = sorted(
            customers["city"]
            .unique()
            .tolist()
        )

        code = """
import pandas as pd

customers = pd.read_csv(
    "data/customers.csv"
)

answer = sorted(
    customers["city"].unique().tolist()
)

print(answer)
"""

        checks.append(
            "✓ city column found"
        )

        checks.append(
            "✓ Unique cities calculated"
        )

        return {
            "status": "ANSWER",
            "answer": ", ".join(city_list),
            "code": code,
            "checks": checks,
            "reason": "Available cities"
        }

    # ----------------------------------------------
    # CURRENCIES
    # ----------------------------------------------

    if (
        "what currencies" in q
        or "which currencies" in q
    ):

        code = """
import pandas as pd

orders = pd.read_csv(
    "data/orders.csv"
)

answer = sorted(
    orders["currency"].unique().tolist()
)

print(answer)
"""

        answer = sorted(
            orders["currency"].unique().tolist()
        )

        checks.append(
            "✓ currency column found"
        )

        checks.append(
            "✓ Unique currencies identified"
        )

        return {
            "status": "ANSWER",
            "answer": ", ".join(answer),
            "code": code,
            "checks": checks,
            "reason": "Available currencies"
        }

    # ----------------------------------------------
    # HIGHEST SALE
    # ----------------------------------------------

    if (
        "highest sale" in q
        or "highest sales" in q
        or "maximum sale" in q
        or "largest sale" in q
        or "biggest sale" in q
    ):

        code = """
import pandas as pd

orders = pd.read_csv(
    "data/orders.csv"
)

orders = orders[
    orders["currency"] == "INR"
]

orders = orders.drop_duplicates(
    subset=["order_id"]
)

answer = orders["amount"].max()

print(answer)
"""

        clean_orders = orders[
            orders["currency"] == "INR"
        ].drop_duplicates(
            subset=["order_id"]
        )

        answer = clean_orders[
            "amount"
        ].max()

        checks.append(
            "✓ INR records selected"
        )

        checks.append(
            "✓ Duplicate orders removed"
        )

        checks.append(
            "✓ Maximum calculated"
        )

        return {
            "status": "ANSWER",
            "answer": str(answer),
            "code": code,
            "checks": checks,
            "reason": "Highest INR sale"
        }

    # ----------------------------------------------
    # LOWEST SALE
    # ----------------------------------------------

    if (
        "lowest sale" in q
        or "minimum sale" in q
        or "smallest sale" in q
    ):

        code = """
import pandas as pd

orders = pd.read_csv(
    "data/orders.csv"
)

orders = orders[
    orders["currency"] == "INR"
]

orders = orders.drop_duplicates(
    subset=["order_id"]
)

answer = orders["amount"].min()

print(answer)
"""

        clean_orders = orders[
            orders["currency"] == "INR"
        ].drop_duplicates(
            subset=["order_id"]
        )

        answer = clean_orders[
            "amount"
        ].min()

        checks.append(
            "✓ INR records selected"
        )

        checks.append(
            "✓ Duplicate orders removed"
        )

        checks.append(
            "✓ Minimum calculated"
        )

        return {
            "status": "ANSWER",
            "answer": str(answer),
            "code": code,
            "checks": checks,
            "reason": "Lowest INR sale"
        }

    # ----------------------------------------------
    # AVERAGE
    # ----------------------------------------------

    if (
        "average sale" in q
        or "average sales" in q
        or "average order" in q
        or "mean sale" in q
    ):

        code = """
import pandas as pd

orders = pd.read_csv(
    "data/orders.csv"
)

orders = orders[
    orders["currency"] == "INR"
]

orders = orders.drop_duplicates(
    subset=["order_id"]
)

answer = round(
    orders["amount"].mean(),
    2
)

print(answer)
"""

        clean_orders = orders[
            orders["currency"] == "INR"
        ].drop_duplicates(
            subset=["order_id"]
        )

        answer = round(
            clean_orders["amount"].mean(),
            2
        )

        checks.append(
            "✓ INR records selected"
        )

        checks.append(
            "✓ Duplicate orders removed"
        )

        checks.append(
            "✓ Average calculated"
        )

        return {
            "status": "ANSWER",
            "answer": str(answer),
            "code": code,
            "checks": checks,
            "reason": "Average INR sale"
        }

    # ----------------------------------------------
    # TOTAL SALES
    # ----------------------------------------------

    if (
        "total sales" in q
        or "total sale" in q
        or "total amount" in q
        or "overall sales" in q
    ):

        if len(currencies) > 1:

            checks.append(
                "❌ Multiple currencies detected"
            )

            return {
                "status": "REFUSED",
                "answer": None,
                "code": "",
                "checks": checks,
                "reason":
                "Cannot safely combine INR and USD."
            }

        code = """
import pandas as pd

orders = pd.read_csv(
    "data/orders.csv"
)

orders = orders.drop_duplicates(
    subset=["order_id"]
)

answer = orders["amount"].sum()

print(answer)
"""

        clean_orders = orders.drop_duplicates(
            subset=["order_id"]
        )

        answer = clean_orders[
            "amount"
        ].sum()

        checks.append(
            "✓ Duplicate orders removed"
        )

        checks.append(
            "✓ Same currency confirmed"
        )

        checks.append(
            "✓ Total calculated"
        )

        return {
            "status": "ANSWER",
            "answer": str(answer),
            "code": code,
            "checks": checks,
            "reason": "Total sales"
        }

    # ----------------------------------------------
    # CITY SALES
    # ----------------------------------------------

    city = None

    for c in customers["city"].unique():

        if c.lower() in q:

            city = c
            break

    if city and (
        "sale" in q
        or "sales" in q
        or "revenue" in q
        or "amount" in q
        or "purchase" in q
    ):

        code = f"""
import pandas as pd

customers = pd.read_csv(
    "data/customers.csv"
)

orders = pd.read_csv(
    "data/orders.csv"
)

df = orders.merge(
    customers,
    on="customer_id"
)

df = df[
    (df["city"] == "{city}")
    &
    (df["currency"] == "INR")
]

df = df.drop_duplicates(
    subset=["order_id"]
)

answer = df["amount"].sum()

print(answer)
"""

        df = orders.merge(
            customers,
            on="customer_id"
        )

        df = df[
            (df["city"] == city)
            &
            (df["currency"] == "INR")
        ]

        df = df.drop_duplicates(
            subset=["order_id"]
        )

        if len(df) == 0:

            return refused(
                f"No reliable sales data found "
                f"for {city}.",
                checks
            )

        answer = df["amount"].sum()

        checks.append(
            f"✓ City detected: {city}"
        )

        checks.append(
            "✓ Tables joined"
        )

        checks.append(
            "✓ INR records selected"
        )

        checks.append(
            "✓ Duplicate orders removed"
        )

        return {
            "status": "ANSWER",
            "answer": str(answer),
            "code": code,
            "checks": checks,
            "reason": f"Sales in {city}"
        }

    # ----------------------------------------------
    # CUSTOMER SALES
    # ----------------------------------------------

    person = None

    for name in customers["name"].unique():

        if name.lower() in q:

            person = name
            break

    if person and (
        "order" in q
        or "purchase" in q
        or "amount" in q
        or "sale" in q
    ):

        code = f"""
import pandas as pd

customers = pd.read_csv(
    "data/customers.csv"
)

orders = pd.read_csv(
    "data/orders.csv"
)

df = orders.merge(
    customers,
    on="customer_id"
)

df = df[
    (df["name"] == "{person}")
    &
    (df["currency"] == "INR")
]

df = df.drop_duplicates(
    subset=["order_id"]
)

answer = df["amount"].sum()

print(answer)
"""

        df = orders.merge(
            customers,
            on="customer_id"
        )

        df = df[
            (df["name"] == person)
            &
            (df["currency"] == "INR")
        ]

        df = df.drop_duplicates(
            subset=["order_id"]
        )

        answer = df["amount"].sum()

        checks.append(
            f"✓ Customer detected: {person}"
        )

        checks.append(
            "✓ Tables joined"
        )

        checks.append(
            "✓ INR records selected"
        )

        checks.append(
            "✓ Duplicate orders removed"
        )

        return {
            "status": "ANSWER",
            "answer": str(answer),
            "code": code,
            "checks": checks,
            "reason": f"Orders for {person}"
        }

    # ----------------------------------------------
    # REFUSE UNKNOWN QUESTIONS
    # ----------------------------------------------

    return refused(
        "The required information was not found "
        "in the available data.",
        checks
    )

# --------------------------------------------------
# EXECUTE PROOF
# --------------------------------------------------

def execute_proof(code):

    if not code:
        return False, ""

    output = io.StringIO()

    try:

        with contextlib.redirect_stdout(output):

            exec(
                code,
                {"pd": pd}
            )

        return True, output.getvalue().strip()

    except Exception as e:

        return False, str(e)

# --------------------------------------------------
# QUESTION BOX
# --------------------------------------------------

st.divider()

st.header("💬 Ask Your Data Question")

question = st.text_input(
    "Enter your question:",
    placeholder=
    "Example: What are the sales in Chennai?"
)

if st.button(
    "🔎 Analyze Question",
    type="primary"
):

    if not question.strip():

        st.warning(
            "Please enter a question."
        )

    else:

        result = analyze_question(
            question
        )

        st.divider()

        st.subheader(
            "🤖 Agent Analysis"
        )

        st.write(
            "**Question:**"
        )

        st.info(question)

        # ------------------------------------------
        # REFUSED
        # ------------------------------------------

        if result["status"] == "REFUSED":

            st.error(
                "🚫 REFUSED"
            )

            st.write(
                result["reason"]
            )

            st.subheader(
                "🔍 Checks Performed"
            )

            for check in result["checks"]:

                st.write(check)

            st.warning(
                "The agent will not invent an answer "
                "when the information is unavailable "
                "or unsafe to determine."
            )

        # ------------------------------------------
        # ANSWER
        # ------------------------------------------

        else:

            proof_code = result["code"]

            verified, output = execute_proof(
                proof_code
            )

            expected = result["answer"]

            if (
                verified
                and
                output == expected
            ):

                st.success(
                    "✅ VERIFIED"
                )

                st.subheader(
                    "📌 Answer"
                )

                st.metric(
                    "Result",
                    result["answer"]
                )

                st.subheader(
                    "🔍 Agent Checks"
                )

                for check in result["checks"]:

                    st.write(check)

                st.success(
                    "✓ Proof code executed successfully"
                )

                st.success(
                    "✓ Proof output matches the answer"
                )

                st.subheader(
                    "🧾 Reproducible Proof Code"
                )

                st.code(
                    proof_code,
                    language="python"
                )

                st.subheader(
                    "▶ Verification Output"
                )

                st.code(output)

            else:

                st.error(
                    "❌ VERIFICATION FAILED"
                )

                st.write(
                    "The proof code did not produce "
                    "the expected result."
                )

                st.code(output)

# --------------------------------------------------
# EXAMPLES
# --------------------------------------------------

st.divider()

st.subheader(
    "💡 Example Questions"
)

examples = [
    "What are the sales in Chennai?",
    "What are the sales in Bangalore?",
    "What are the sales in Coimbatore?",
    "What is the highest sale?",
    "What is the lowest sale?",
    "What is the average sale?",
    "How many customers are there?",
    "How many orders are there?",
    "How many products are there?",
    "Which cities are available?",
    "What currencies are present?",
    "What are Ravi's orders?",
    "What are Priya's sales?",
    "What are the total sales?"
]

for example in examples:

    st.write(
        "• " + example
    )

st.divider()

st.caption(
    "HNX26PSI08 | Proof-Carrying Data Analyst | "
    "Agentic GenAI"
)
